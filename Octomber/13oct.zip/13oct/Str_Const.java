class Str_Const2{

	public static void main(String[] args) {
		
		char []name = {'D','A','M','S'};
		String s1 = new String(name);
		System.out.println(s1);
		System.out.println(s1.length());

        byte []barr = {100,101,102,103};
		String s2 = new String(barr);
		System.out.println(s2);
		System.out.println(s2.length());


	}
}