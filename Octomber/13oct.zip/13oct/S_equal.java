class S_Equal{

	public static void main(String[] args) {
		
		String s1 = new Object("Damodar");
		String s2 = new Object("Dikonda");

		Object o1 = new Object("Damodar");
        Object o2 = new Object("Damodar");
		System.out.println(s1.equals(s2));
	}
}