import java.util.*;

class Jagged3d{

	public static void main(String[] args) {
		 
          Scanner sc = new Scanner(System.in);

          double darr[][][] = new double[2][][];
          
          darr[0][0] = new double[0][2];                                                                                    
          darr[0][1] = new double[1][3];
         darr[0][2]  = new double[2][4];

          darr[1][0]  = new double[0][2];
          darr[1][1]  = new double[1][3];
          darr[1][2]  = new double[2][4];
          
           for (int i = 0 ; i < 2 ; i++ ) {
           	
           	   for (int j = 0 ; j < darr.length ;  j++) {
           	   	
           	   	for (int k = 0 ; k < darr[j].length ; j++ ) {
           	   		
           	   		darr[i][j][k] = sc.nextInt();
           	   	}
           	   }
           }
          
          System.out.println("EnteredValues are = ");
          for (int i = 0 ; i < 2 ; i++ ) {
           	
           	   for (int j = 0 ; j < darr.length ;  j++) {
           	   	
           	   	for (int k = 0 ; k < darr[j].length ; j++ ) {
           	   		
           	   		darr[i][j][k] = sc.nextInt();
           	   	}
           	   }
           }

		}
}