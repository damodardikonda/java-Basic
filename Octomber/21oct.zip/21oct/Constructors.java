class PuneCity{

	PuneCity(){

		System.out.println(" No Arguments Wala Constructors");
	}

	public static void main(String[] args ){

		PuneCity pune = new PuneCity();
	}
}