import java.util.*;
class P2{

	public static void main(String[] args) {
		
          Scanner sc = new Scanner(System.in);

          System.out.println("Enter the String");
          String s = sc.nextLine();

          int len = s.length();

          System.out.println("The Length of String is = " + len);
	}
}