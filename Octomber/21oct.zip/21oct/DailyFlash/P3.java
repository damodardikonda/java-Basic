import java.util.*;
class P3{

	public static void main(String[] args) {
		
        Scanner sc = new Scanner(System.in);

        String str = sc.nextLine();

       int len = str.length();

       if(len > 5 ){

       	    System.out.println(str);
       }
	}
}