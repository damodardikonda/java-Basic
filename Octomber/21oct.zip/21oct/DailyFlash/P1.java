class P1{

	public static void main(String[] args) {
		
		byte b[] = {97,65,66,67,68,69,97};

		String str = new String(b);

		System.out.println(str);
	}
}