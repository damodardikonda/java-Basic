
class P5{
	
	public static void main(String[] args) {
		
		StringBuffer s1 = new StringBuffer("Core2web");
		s1.append("Technologies");

		System.out.println(s1);
	}
}