
class P1{

	public static void main(String[] args) {
		
		String s1 = " Damodar " ; // String Literals
		String s2 = new String("Dikonda");

		System.out.println(s1 + "  " + s2);
	}
}