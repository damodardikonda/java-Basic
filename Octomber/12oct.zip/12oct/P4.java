class P4{
	
	public static void main(String[] args) {
		
		String s1 = "Damodar";
		String s2 = new String("Dikonda");   
        System.out.println(s1);
        System.out.println(s2);


		
		String s2 = "Damodar";
		String s1 = new String("Dikonda");   
        System.out.println(s1); //already defined
        System.out.println(s2); // already defined

	}
}