class IPLLL{

     void IPLLL(){

     	System.out.println("HIIIIIII");
     }

     public static void main(String[] args) {
     	
     	IPLLL o = new IPLLL();
     }
}