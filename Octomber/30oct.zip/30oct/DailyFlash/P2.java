class P2{
	
	public static void main(String[] args) {
		
		StringBuffer sb = new StringBuffer("Coer2webTechnologies");

		System.out.println("Character at 5 is "+sb.charAt(5));
		System.out.println("index of character 2 is " + sb.indexOf("2"));
	}

}