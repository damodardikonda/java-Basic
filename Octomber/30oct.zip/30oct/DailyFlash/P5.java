class P5{
	public static void main(String[] args) {
		
		StringBuffer sb = new StringBuffer("Aquaman");
		sb = sb.delete(4 , 6);
        System.out.println(sb);
	}
}