class Trial {
	
	public static void main(String[] args) {
		
		System.out.println(" Main method");
	}

	public static void main(String[] args) {
           
           System.out.println(" 2nd main method");		
	}

}

// double main method is not allowed