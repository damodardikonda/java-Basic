class PlayBook{

	static class Book{

		void orderBook(){

			System.out.println("Sanyasi jyane apli sampatti vikli");
		}
	}
}

class OrderBook{

	public static void main(String[] args) {
		
		PlayBook.Book b = new PlayBook.Book();
		b.orderBook();

	}
}