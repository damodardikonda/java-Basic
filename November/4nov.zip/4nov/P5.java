import java.io.*;

class Demo{
	
	public static void main(String[] args) {
		
		int inst[10] = {10,  20 ,  30 , 40 ,  60 ,  70 ,80 , 90,100};

		for (int i = 0 ;  i < 10 ; i++ ) {
			
			System.out.println("Enter name of object");

			String name = sc.next();

			Demo  name = new Demo[10];
            
			
		}

		


	}
}