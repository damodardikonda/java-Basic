class Outer {

	class Inner{

		
	}
}