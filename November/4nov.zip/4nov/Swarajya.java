class Swarajya{

	Swarajya(){

		System.out.println("Swarajyache Sansthapak Shree Shree Shree Chatrapati Shivaji Maharaj");
	}

	class Kondhana{

		void gadFatte(){

              System.out.println("Subhedar Tanaji Malusare  Sobat fakt 800 mavale gheun");
		}
	}


	class Pavan_Khind{

         void khindLadhavane(){
	          
	          	System.out.println("Subhedar BajiPrabhu Deshpande Sobat Fakt 300 maavale gheun ");
	   	    }
    
	}

    class Panhala{


         void gadFatte(){
	          
	          	System.out.println("Subhedar Kondoji Farjand Sobat Fakt 60 maavale gheun ");
	   	    }
    }

     public static void main(String[] args) {

     	Swarajya aplarajya = new Swarajya();

     	Kondhana sinhgad = aplarajya.new Kondhana();
     	sinhgad.gadFatte();

     	Pavan_Khind khind = aplarajya. new Pavan_Khind();
     	khind.khindLadhavane();
    	
    	Panhala panhalla = aplarajya. new Panhala();
    	panhalla.gadFatte();
    }
}