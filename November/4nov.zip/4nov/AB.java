class A{

	class B{

		
	}
}