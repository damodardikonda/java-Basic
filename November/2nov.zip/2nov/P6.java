class P6{

		
		String Ename = "Damodar";
		String Company = "Biencaps";

		P6(){
			System.out.println("In Constructor = ");
			System.out.println("Employee Name is = " + Ename);
			System.out.println("Company Name is = " + Company);
		}


        public static void main(String[] args) {
	
	       P6 obj = new P6();
        }
	


}