class P5{
 

      P5( String name){

              System.out.println(name);
      }

     static String name = "Damodar";


	public static void main(String[] args) {
		
		
		P5 obj = new P5(name);
	}
}