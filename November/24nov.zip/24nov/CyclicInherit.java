class A extends B{


}

class B extends A{



}


