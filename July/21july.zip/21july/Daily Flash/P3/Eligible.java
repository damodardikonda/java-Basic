import java.util.Scanner;


class Eligible{

	public static void main(String[] args) {
		
		
        int age= 10;

        String ans=null;

        ans= (age >= 18) ? "You are Eligible " : "  you are Not Eligible";
        System.out.println(ans);


	}
}