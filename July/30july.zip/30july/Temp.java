class Temp{
	
	public static void main(String[] args) {
		
		int x = 10,a;
		int y = -10,b;

		a = x >> 2;
		b = y >>> 2;

		System.out.println(a);
		System.out.println(b);

	}
}