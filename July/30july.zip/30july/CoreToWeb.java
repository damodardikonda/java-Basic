class CoreToWeb{
	
	static int total = 8000;

    public static void main(String args[]){
	
	   int batch_count = 70;

	   CoreToWeb java10 = new CoreToWeb();

	   System.out.println(" Total Number of students are = " +java10.total);

	   System.out.println(" Java10 Batch student count is =" + batch_count);
  
    }


}

