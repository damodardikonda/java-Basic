class Operator{

	public static void main(String[] args) {
		
		int x = ??;

		if((x & (x-1)) == 0)
			System.out.println(x); 
	}
}