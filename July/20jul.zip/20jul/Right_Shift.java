class Right_Shift{

	public static void main(String[] args) {
		
		int num1=95;
		int num2=-95;
		int num3=-60;


		int res;

		res=num1>>2;
		System.out.println(res);

		res=num2>>4;
		System.out.println(res);

		res=num3>>2;
		System.out.println(res);


	}
}