class Unsigned_R_S{

	public static void main(String[] args) {
		
		int num=35;

		int res=0;

		res=num>>>5;

		System.out.println("Unsign Right Shift is"+res);
		
	}
}