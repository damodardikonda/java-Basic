class Left_Shift{

	public static void main(String[] args) {
		
		int num1=12;
		int num2=75;
		int num3=-12;


		int res;

		res=num1<<2;
		System.out.println(res);

		res=num2<<4;
		System.out.println(res);

		res=num3
		<<2;
		System.out.println(res);


	}
}