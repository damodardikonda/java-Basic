/*Write a Java Program to check if the Bitwise operators given below works on int, long,
char, float, and double data types
1. Bitwise AND (&)
2. Bitwise OR (|*?)
3. Bitwise XOR (^)
And also write down your conclusion in the comments.*/


// Bitwise operations doesnt performed on float  and double

class Bitwise_Float{

	public static void main(String[] args) {
		
		float num1=20.0f;
	    float num2=30.0f;
	    float and_ans1;
	    float or_ans1;
	    float xor_ans1;

/*	    and_ans1= num1 & num2;  // Bitwise And doesnt performed on float
	    System.out.println("Bitwise AND for integer= "+and_ans1);

	    or_ans1= num1 | num2;  //30
	    System.out.println("Bitwise OR for integer="+or_ans1);

	    xor_ans1= num1 ^ num2;  //10
	    System.out.println("Bitwise XOR for integer="+xor_ans1);
*/
	}
}