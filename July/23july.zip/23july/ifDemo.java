class ifDemo{
	 public static void main(String[] args) {
	 	
	 	int x=10;
	 	int y=20;
	 	int z=30;

	 	
	 	if(x>y){  //(10>20)-->false
	 	
	 	      System.out.println("x is less" + x);
	 }

	 System.out.println("Out of If");


	 if(z>y){  //(30<20)-->true
	 	
	 	      System.out.println("z is greater" + z);
	 }

	}
}