class Pre_If{
	
	public static void main(String[] args) {
		
		int x=10;

		if(++x <=10){ // false.. adhi x chi value vadhv ntr check kr

			System.out.println("X is less Than 10");
		}

			System.out.println("X is Greater Than 10");
	}
}