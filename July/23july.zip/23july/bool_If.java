class bool_If{
	
	public static void main(String[] args) {
		
		int x=10;
		int y=20;

		if(x!=0 && y<=10){ 

			System.out.println(" Hiiiii");


		}

			System.out.println("Hellloooo");
	


	boolean  a=true;
	boolean b = false;


	if(a && b){

					System.out.println(" Hiiiii");

	}

       			System.out.println("Hellloooo");
     
    }        

}