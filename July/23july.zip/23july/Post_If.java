class Post_If{
	
	public static void main(String[] args) {
		
		int x=10;

		if(++x <=10){ // True.. adhi X chi value check kr ntr  x chi value vadhv

			System.out.println("X is less Than 10");
			System.out.println(x);//11


		}

			System.out.println("X is Greater Than 10");
	}
}