
class Weekdays1{

	public static void main(String[] args) {
		
	char s = 'b';
     
        System.out.println("Before Switch");

		switch(s){


			case a:

			      System.out.println("Monday");
			      break;
		    
		    case b:

			      System.out.println("Tuesday");
			      break;

			case c:

			      System.out.println("Wednesday");
			      break;

			case d:

			      System.out.println("Thursday");
			      break;

			case e:

			      System.out.println("Friday");
			      break;

			case f:

			      System.out.println("Saturday");
			      break;

			case g:

			      System.out.println("Sunday");
			      break;


			default:

			     System.out.println("Upto 7 only");
			     break;


		}

	        System.out.println("After Switch");

	}
}