class UpperLower{

	public static void main(String args[]){

		String ch = 'a';

		String abc;

        if( ch == isLowerCase(ch) ){

            abc=ch.toUpperCase();
            System.out.println(abc);

        } else if( ch == isUpperCase(ch)){

        	abc = ch.toLowerCase();
            System.out.println(abc);


        }


	}
}
