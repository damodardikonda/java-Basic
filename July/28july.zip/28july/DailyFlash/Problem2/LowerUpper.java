class UpperLower{

	public static void main(String args[]){

		char ch='a';

        if(ch == 'a'){

            System.out.println('A');

        } else if(ch == 'A'){

            System.out.println('a');
        }


		

        }


	
}
