class UpperLower{

	public static void main(String args[]){

		char ch = 'a';

		char abc;

        if( ch == 'a' ){

            abc=ch.toUpperCase();
            System.out.println(abc);

        } else if( ch == 'A'){

        	abc = ch.toLowerCase();
            System.out.println(abc);


        }


	}
}
