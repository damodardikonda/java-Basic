class SwitchDemo2{
	
	public static void main(String[] args) {
		
		int y=2;


		switch(y){

			case 5:

			    System.out.println(" Five");
			    break;

			case 2: 

			     System.out.println("Two ");
			     break;

			case 10: 

			     System.out.println("Ten ");
			     break;
		}
	}
}