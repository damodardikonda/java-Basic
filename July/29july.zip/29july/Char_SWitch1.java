class Char_Switch1{

	public static void main(String[] args) {
		
		char ch = 'A';//Error
		

		switch(ch){

			case 'A':
			   System.out.println(" A char");
			   break;

			case 65:
			   System.out.println(" A val");
			   break;


			
		}
	}
}