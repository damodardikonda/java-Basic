class String_Switch{
	
	public static void main(String[] args) {
		
		String s = "Damodar";

		switch(s){

			case "Damodar":
			  System.out.println("Damodar dikonda");
			  break;

			case "damodar":
			  System.out.println("damodar............");
			  break;


		}
	}
}