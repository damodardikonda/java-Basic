class Str_Switch{
	
	public static void main(String[] args) {
		
		String s = new String("Damodar");

		switch(s){

			case "Damodar":
			  System.out.println("Damodar dikonda");
			  break;

			case "damodar":
			  System.out.println("damodar............");
			  break;


		}
	}
}