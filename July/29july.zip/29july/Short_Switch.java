class Short_Switch{

	public static void main(String[] args) {
		
		short s = 100;

		switch(s){

			case 100:
			   System.out.println("First Case");
			   break;

			case 200:
			   System.out.println("Second Case");
			   break;
		}
	}
}