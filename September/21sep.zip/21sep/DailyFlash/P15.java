class P15{
	
	public static void main(String[] args) {
		int cube = 1;
		for (int i = 1 ; i <=8 ; i++) {
			cube = i*i*i;
			System.out.print(cube + " " );
		}
	}
}