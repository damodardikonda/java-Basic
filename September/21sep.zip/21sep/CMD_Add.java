class CMD{

	public static void main(String[] args) {
		
		int add = 0;

        
      int x = Integer.parseInt(args[0]);
      int y  = Integer.parseInt(args[1]);

       add = x + y ;
              System.out.println(" Addition is " + add);
	}
}