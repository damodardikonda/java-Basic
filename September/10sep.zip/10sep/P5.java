class P5 {
 
    public static void main(String[] args) {
    	int num = 1;
        int s = 0;
    	for (int i = 1 ; i < 4 ; i++ ) {
    		
    		for (int j = 1 ; j < 4 ; j++ ) {
    			 
                 s = (num*num) - 1 ;

    			System.out.print( s + " ");
                num++;
    		}

    		System.out.println();

    		    	}
    }

}