import java.util.Scanner;

class P3{
	
	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);

      
        int hr = sc.nextInt();

        int sec = hr * 3600;

       System.out.println(" Second is  " + sec);

   }}