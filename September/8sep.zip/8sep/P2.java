import java.util.Scanner;

class P2{
	
	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);

		float rs = sc.nextFloat();

		float doller = rs * 69.35f;

		System.out.println(doller);

	}

}