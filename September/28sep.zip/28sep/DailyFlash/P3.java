import java.util.*;

class P3{

	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);

		String strid = sc.next();

		int intid=sc.nextInt();

		System.out.println(strid+intid+"@gmail.com");
	}
}