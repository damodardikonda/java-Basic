import java.util.*;

class P1{

	public static void main(String[] args) {
		
        
        Scanner sc = new Scanner(System.in);
        String name = sc.next();
        int roll = sc.nextInt();
        String interest = sc.next();

        System.out.print("Hey , my name is " + name + " and my roll no is " + roll +". My field of interests are " + interest );
	}
}