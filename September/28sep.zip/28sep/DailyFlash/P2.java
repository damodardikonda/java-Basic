import java.util.*;

class P2{
	
	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);

		String str1 = sc.next();
		String str2 = sc.next();

		System.out.println(str1 + " " + str2);
	}

}