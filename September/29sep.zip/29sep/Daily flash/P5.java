
class P5{
	
	public static void main(String[] args) {
		
		String a[] = {"A","B","C","D","E"};
        
		for (int i = 0 ; i < 5 ; i++) {
			
			String l =  a[i].toLowerCase();
			System.out.println(l);
		}
	}
}