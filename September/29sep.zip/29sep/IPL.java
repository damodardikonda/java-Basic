class IPL{
	
	public static void main(String[] args) {
		
		IPL ipl = new IPL();
	    System.out.println( ipl.getClass());
	}
}