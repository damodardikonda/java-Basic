class Float_Runtime_Sign{
	
	public static void main(String[] args) {
		
		float f_arr[] = new float[5];
		double[] db = new double[5];
        String[] damodar = new String[5];
        char[] ch = new char[10];
        byte[] b = new byte[5];
        short[] s = new short[5];
        long[] l = new long[1];

        System.out.println(f_arr.getClass());
	    System.out.println(damodar.getClass());
	    System.out.println(db.getClass());
	    System.out.println(ch.getClass());
	    System.out.println(b.getClass());
	    System.out.println(s.getClass());
	     System.out.println(f_arr.getClass());
	
	}
}
