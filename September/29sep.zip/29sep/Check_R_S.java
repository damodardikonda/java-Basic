class Sample{
	
	public static void main(String[] args) {
		
		int a = new int;

		System.out.println(a.getClass());
	}
}