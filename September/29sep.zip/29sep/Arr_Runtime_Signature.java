class Arr_Runtime_Signature{
	
      public static void main(String[] args) {
      	

      	 int[] a = new int[5];

      	 System.out.println(a.getClass());
      }

}