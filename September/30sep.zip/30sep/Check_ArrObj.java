class Arr_Obj{

	public static void main(String[] args) {
		
		int arr[] = {10,20,30,40,50};

		print(" Class Name is " + arr.getClass());
	}
}