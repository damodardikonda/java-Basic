class P1{
	
	public static void main(String[] args) {
		
		int arr[] = {1789 , 2035 , 1899 , 2013 ,1458, 2458 , 1254 , 1472 , 2365};

		for (int i = 0 ; i < arr.length ; i++ ) {
		 	
		 	if(arr[i] == 2013 ){

		 		System.out.println("2013 is present at " + i + " Location");
		 	}

		 	else if(arr[i] == 2015 ){

		 		System.out.println("2013 is present at " + i + " Location");
		 	}


		 } 

		 
	}
}