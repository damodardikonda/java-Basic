class Fact{

	public static void main(String[] args) {
		int f = 1 , i = 1;
		for ( i = 1 ; i <= 5 ; i++ ) {
			
			f = f * i ;
			}
             int temp = i-1;
			System.out.println("Factorial of " + temp + " is:= " + f);
		
	}
}