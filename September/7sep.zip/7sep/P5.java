import java.util.Scanner;

class P5{
	
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println(" Enter Real part");
		int real = sc .nextInt();
		System.out.println(" Enter Real part");
		int real2 = sc .nextInt();
		System.out.println(" Enter imaginory part");
		float imag = sc .nextFloat();
		System.out.println(" Enter imag part");
		int img2 = sc .nextInt();
	
	int real3 = real + real2;
	int i = (int) imag + img2;

	System.out.println(real3+"+"+i+"i");
	}
	}
