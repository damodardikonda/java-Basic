/*

 
*/


class P4{

	public static void main(String[] args) {
		
		for (int i = 1 ; i < 6 ; i++ ) {
			int ch = 65;
			for (int j = 0 ; j <=4 ;j++ ) {
				
				System.out.print((char)(ch+j)  + " ");
			}
		 
		  System.out.println();
		}

	}
}