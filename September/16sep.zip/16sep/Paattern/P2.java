/*

1 8 27 64 125 216 343 512

?*

class P2{

	public static void main(String[] args) {
		
		for (int i = 1 ; i <= 8 ; i++ ) {
			
			System.out.print(i*i*i + " ");
		}

		System.out.println(); 
	}
}