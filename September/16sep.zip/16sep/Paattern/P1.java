/*

2 3 4 6 6 9 8 12 10 15 12 18 14 21 16 24 18 27 20 30

*/


class P1{
	
	public static void main(String[] args) {
		
		for (int i = 1 ; i <= 10  ; i++ ) {
			
			System.out.print(i*2 + " " + i*3 + " ");
		}

		System.out.println();
	}
}