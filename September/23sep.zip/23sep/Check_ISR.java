import java.io.*;
import java.util.*;
class Check{
	
	public static void main(String[] args) throws IOException {
		
         InputStreamReader isr = new InputStreamReader(System.in);
         BufferedReader br = new BufferedReader(isr);

        char ch = (char)isr.read();
         //String s = br.readLine();
         //int a = isr.read();

         System.out.println(ch);
         //System.out.println(a);
	}
}