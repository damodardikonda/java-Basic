import java.util.Scanner;

class P5{
	
	public static void main(String[] args) {
		
		Scanner sc = new Scanner( System.in);
		int a = sc.nextInt();
		int b = sc.nextInt();
       
       if( a > b){

       	   System.out.println(" The Maximum number amongs 56 & 99 is " + a);
       }
       else

       	   System.out.println(" The Maximum number amongs 56 & 99 is " + b);
   


		
	}
}