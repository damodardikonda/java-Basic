

class P3{
	
	public static void main(String[] args) {
		
      int s = 0;
      int c = 0 ;
       for (int i = 1; i <= 10  ; i++ ) {
       		
       		s= i*i;
       		c = i*i*i;
       		System.out.println(" Square is " + s + " Cube is " + c);

       	}	



	}
}