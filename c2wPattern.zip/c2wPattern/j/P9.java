class P9{
	
	public static void main(String[] args) {
		
		for ( char ch = 'A' ; ch <= 'Z' ;ch++ ) {
			
			System.out.printf("%c = %d \n " , ch ,(int)ch );
		}
	}
}