class P11{

	public static void main(String[] args) {
		
		int c=0;

		for ( int i = 1 ; c < 5 ; i++) {
			
			if(i%5==0){
				System.out.println(i);
				c++;
			}
		}
	}
}