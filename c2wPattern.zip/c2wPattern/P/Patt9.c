#include<stdio.h>
void main(){

	for ( char  i = 'A' ; i <= 'Z' ; ++i)
	{
		printf("%d = %c \n", (int)i , i );
	}
}