ch = 'A'
i = 0
while(ch <= 'Z'):
    print(ch+i , end="=")
    print(ord(ch))
    i+=1
print()
