for i in range( 1 , 16 ):
    if i % 2 == 0:
        print("Even = " ,i)
    else:
        print("Odd = " , i)
