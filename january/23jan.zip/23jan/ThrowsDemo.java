import java.io.*;

class ThrowsDemo{

	public static void main(String[] args) throws IOException , ArithmeticException {

		BufferedReader br = new BufferedReader( new InputStreamReader(System.in));

		System.out.println(br.readLine());		

	}
}