class NullPointerDemo{

	public static void main(String[] args) {
		
		NullPointerDemo o = null;
		o.fun();
	}

	void fun(){

		System.out.println(" In Fun");
	}
}