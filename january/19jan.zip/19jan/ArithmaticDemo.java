class ArimaticDemo{

	public static void main(String[] args) {
		
		System.out.println("Divide by zero ");
		System.out.println(10/0);
	}
}