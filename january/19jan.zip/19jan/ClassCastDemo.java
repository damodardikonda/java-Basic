class ClassCastDemo{
	
	public static void main(String[] args) {
		
		Object o = new Integer(10);
		String s = (String)o;
		
	}
}