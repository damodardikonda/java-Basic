class S{

	public static void main(String[] args){

		String s= "Damodar Dikonda";

		int a = (int)' ';
		System.out.println(a);
	}
}
