class Str{
	
	public static void main(String[] are){
		
		String s= " I Love My Country";
	
            char rev[] = s.toCharArray();
	    
		for(int i = rev.length-1 ; i >= 0 ;i--)

		

		System.out.print(rev[i]);		
	}
}
