class Pattern1{


     public static void main(String[] args) {
	
	

	for(int i =1; i<=4; i++){

		int num =4 ;

		for(int j = i ;j >=1 ;j--){

			
			 System.out.print(num + " ");
			 num--;
                


		}

           System.out.println();
           
	}

	}	
}