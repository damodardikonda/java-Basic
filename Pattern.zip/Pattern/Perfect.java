class Perfect{
	
	public static void main(String[] args) {
		
		int i;
		int ld;
		int j,total=0;
        int sum=0;
		for(i=1;i<100;i++){



			for(j=1;j<=i;j++){

				if(i%j==0){

					sum=sum+j;



				if(sum == i){

					System.out.println(sum + "is prime number");

					total = total+sum;

					}




					}
				}



				}

				

				


				
		}
	}
}
}