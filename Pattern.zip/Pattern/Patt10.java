class Patt10{
	
	public static void main(String[] args) {
		
		int i,j;
         char ch ='A';
         int max=4;
         int min=max-1;
		for(i=0;i<max;i++){

			for(j=1;j<min;j++){


				System.out.print(ch);
				ch++;
			min--;




			}
		}
	}
}