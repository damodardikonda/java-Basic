class IOWrong{

	static ArithmeticException ar = null;

	public static void main(String[] args) {
			
			throw ar;	
	}
}