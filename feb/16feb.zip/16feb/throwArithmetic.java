class ArithmeticThrow{

	public static void main(String[] args) {
		
		throw new ArithmeticException("Apla Exception");
	}
}