import java.io.*;


class ThrowDemo{
	
	ThrowDemo() throws ArithmeticException , IOException,InterruptedException{


	}
	public static void main(String[] args) {
		

	}
}