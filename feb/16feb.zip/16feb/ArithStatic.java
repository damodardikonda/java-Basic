class ArithStatic{

   static ArithmeticException ae = new ArithmeticException();
	public static void main(String[] args) {
		
         throw ae;
	}
}